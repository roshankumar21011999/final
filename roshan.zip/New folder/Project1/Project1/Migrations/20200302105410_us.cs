﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Project1.Migrations
{
    public partial class us : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Address",
                columns: table => new
                {
                    AddressId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Street_Address1 = table.Column<string>(nullable: true),
                    Street_Address2 = table.Column<string>(nullable: true),
                    City = table.Column<string>(nullable: true),
                    State = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Address", x => x.AddressId);
                });

            migrationBuilder.CreateTable(
                name: "carCategories",
                columns: table => new
                {
                    CatgoriesId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Brand = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_carCategories", x => x.CatgoriesId);
                });

            migrationBuilder.CreateTable(
                name: "discountDetails",
                columns: table => new
                {
                    DiscountId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CustomerType = table.Column<string>(nullable: true),
                    Discount = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_discountDetails", x => x.DiscountId);
                });

            migrationBuilder.CreateTable(
                name: "orders",
                columns: table => new
                {
                    OrderId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Start = table.Column<string>(nullable: true),
                    End = table.Column<string>(nullable: true),
                    Priceperday = table.Column<string>(nullable: true),
                    Estimated_Km = table.Column<float>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_orders", x => x.OrderId);
                });

            migrationBuilder.CreateTable(
                name: "registerations",
                columns: table => new
                {
                    RegisterationId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EmailId = table.Column<string>(nullable: true),
                    Password = table.Column<string>(nullable: true),
                    Name = table.Column<string>(nullable: true),
                    Gender = table.Column<string>(nullable: true),
                    Occupation = table.Column<string>(nullable: true),
                    Address = table.Column<string>(nullable: true),
                    DOB = table.Column<string>(nullable: true),
                    PhoneNo = table.Column<long>(nullable: false),
                    AadharNo = table.Column<long>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_registerations", x => x.RegisterationId);
                });

            migrationBuilder.CreateTable(
                name: "cars",
                columns: table => new
                {
                    VehicleId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Description = table.Column<string>(nullable: true),
                    model = table.Column<string>(nullable: true),
                    ImgUrl = table.Column<string>(nullable: true),
                    CostPerMile = table.Column<int>(nullable: false),
                    CatgoriesId = table.Column<int>(nullable: false),
                    carCategorieCatgoriesId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_cars", x => x.VehicleId);
                    table.ForeignKey(
                        name: "FK_cars_carCategories_carCategorieCatgoriesId",
                        column: x => x.carCategorieCatgoriesId,
                        principalTable: "carCategories",
                        principalColumn: "CatgoriesId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "carCategories",
                columns: new[] { "CatgoriesId", "Brand" },
                values: new object[,]
                {
                    { 1, "Audi" },
                    { 2, "Maruti Suzuki " }
                });

            migrationBuilder.InsertData(
                table: "cars",
                columns: new[] { "VehicleId", "CatgoriesId", "CostPerMile", "Description", "ImgUrl", "carCategorieCatgoriesId", "model" },
                values: new object[,]
                {
                    { 1, 2, 20, " the boxes categorically used for the engine, passenger, and cargo.", "https://i.ndtvimg.com/i/2015-11/maruti-suzuki-ciaz-827_827x510_61447071611.jpg", null, "Ciaz" },
                    { 2, 2, 15, "A hatchback is a car type with a rear door that opens upwards. They typically feature a four-door configuration, excluding the rear door ", "https://i.ndtvimg.com/i/2016-04/maruti-suzuki-swift_827x510_71460371276.jpg", null, "Swift" },
                    { 3, 1, 17, " They feature either a retractable hardtop roof or soft folding top. ", "https://i.ndtvimg.com/i/2014-12/audi-a3-cabriolet-3_625x300_51417497918.jpg", null, "A3" }
                });

            migrationBuilder.InsertData(
                table: "discountDetails",
                columns: new[] { "DiscountId", "CustomerType", "Discount" },
                values: new object[,]
                {
                    { 1, "yearly membersship", "50" },
                    { 2, "Monthly members", "25" },
                    { 3, "half yearly members", "25" }
                });

            migrationBuilder.InsertData(
                table: "registerations",
                columns: new[] { "RegisterationId", "AadharNo", "Address", "DOB", "EmailId", "Gender", "Name", "Occupation", "Password", "PhoneNo" },
                values: new object[,]
                {
                    { 1, 8888666633332222L, "xhg czdfgbvd  bvkudfjvb duc h", "21.01.1999", "kr21101999@gmail.com", "Male", "roshan", "Emp", "kr21101999@gmail.com", 9873275357L },
                    { 2, 3338666633332222L, "xhg czdfgbvd  bvkudfjvb duc h", "26.01.1997", "sk21101999@gmail.com", "Male", "saurabh", "Emp", "sk21101999@gmail.com", 9873275357L },
                    { 3, 8228666633332222L, "xhg czdfgbvd  bvkudfjvb duc h", "06.01.1995", "sd21101999@gmail.com", "Male", "shubham", "Emp", "sd21101999@gmail.com", 9873275357L }
                });

            migrationBuilder.CreateIndex(
                name: "IX_cars_carCategorieCatgoriesId",
                table: "cars",
                column: "carCategorieCatgoriesId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Address");

            migrationBuilder.DropTable(
                name: "cars");

            migrationBuilder.DropTable(
                name: "discountDetails");

            migrationBuilder.DropTable(
                name: "orders");

            migrationBuilder.DropTable(
                name: "registerations");

            migrationBuilder.DropTable(
                name: "carCategories");
        }
    }
}
