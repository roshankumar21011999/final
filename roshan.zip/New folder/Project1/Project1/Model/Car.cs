﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Project1.Model
{
    public class Car
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int VehicleId { get; set; }
        public string Description { get; set; }

        public string model { get; set; }
        public string ImgUrl { get; set; }
        public int CostPerMile { get; set; }
        public int CatgoriesId { get; set; }
        public CarCategorie carCategorie { get; set; }
        
    }
}
