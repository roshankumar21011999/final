﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Project1.Model
{
   
    public class Order
    {
        
        public int OrderId { get; set; }



       
        public string Start { get; set; }



       
        public string End { get; set; }



       
        public string Priceperday { get; set; }



       
        public float Estimated_Km { get; set; }

    }
}
