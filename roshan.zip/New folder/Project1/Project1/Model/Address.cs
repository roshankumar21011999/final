﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Project1.Model
{
    public class Address
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int AddressId{ get; set; }



        public string Street_Address1 { get; set; }




        public string Street_Address2 { get; set; }




        public string City { get; set; }




        public string State { get; set; }
    }
}
