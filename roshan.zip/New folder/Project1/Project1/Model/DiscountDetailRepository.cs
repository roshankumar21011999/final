﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project1.Model
{
    public class DiscountDetailRepository: IDiscountDetailRepository
    {
        private readonly AppDbContext _appDbContext;

        public DiscountDetailRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public IEnumerable<DiscountDetail> AllDiscount
        {
            get
            {
                return _appDbContext.discountDetails.ToList();
            }
        }
    }
}
